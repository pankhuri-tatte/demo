package com.test.assignment_28nov;

import java.util.Scanner;
import java.lang.String;

public class ReverseString {

	/**
	 * The program prints the reversed string. 
	 * @param args
	 */
	public static void main(String[] args) {
			char ch,ch1;
			String s,rstring="";
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter the string");
			s=sc.nextLine();
			//calculates the length of string
			int len=s.length();  
			
			//logic to reverse the string
			for(int i=len-1; i>=0 /*exits the loop when i equals 0*/; i--)
			{
				  rstring=rstring+s.charAt(i);
			}
			//prints the reversed string
			System.out.println(rstring);   

	}

}
