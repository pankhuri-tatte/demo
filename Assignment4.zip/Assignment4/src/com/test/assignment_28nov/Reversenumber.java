package com.test.assignment_28nov;
import java.util.Scanner;

public class Reversenumber {

	/**
	 * The program prints the number entered in reverse order
	 * @param args
	 */
	public static void main(String[] args) {
		int n;
		String rnum="";
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		n=sc.nextInt();
		
		//calculates the length of the number
		int length=String.valueOf(n).length();
		
		//logic to reverse the number
		for(int i=1;i<=length;i++)
		{
			int rem=n%10;
			rnum=rnum+rem;
			n=n/10;
		}
		//prints the reversed number
		System.out.println(rnum);
		
	}

}
